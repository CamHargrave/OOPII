﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public class Dime : USCoin
    {
        public Dime(USCoinMintMark DMint)
        {
            MintMark = DMint;
            this.Name = "Dime";
            this.MonetaryValue = .10;

        }
        public Dime()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Dime";
            this.MonetaryValue = .10;
        }
    }
}
