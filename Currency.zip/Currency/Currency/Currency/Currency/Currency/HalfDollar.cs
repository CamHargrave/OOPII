﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public class HalfDollar : USCoin
    {
        public HalfDollar(USCoinMintMark HDMint)
        {
            MintMark = HDMint;
            this.Name = "Half Dollar";
            this.MonetaryValue = .50;

        }
        public HalfDollar()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Half Dollar";
            this.MonetaryValue = .50;
        }
    }
}
