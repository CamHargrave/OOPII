﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public class Nickel : USCoin
    {
        public Nickel(USCoinMintMark NMint)
        {
            MintMark = NMint;
            this.Name = "Nickel";
            this.MonetaryValue = .05;

        }
        public Nickel()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Nickel";
            this.MonetaryValue = .05;
        }
    }
}
