﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public class DollarCoin : USCoin
    {
        public DollarCoin(USCoinMintMark DCMint)
        {
            MintMark = DCMint;
            this.Name = "Dollar Coin";
            this.MonetaryValue = 1;

        }
        public DollarCoin()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Dollar Coin";
            this.MonetaryValue = 1;
        }
    }
}
