﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public class Quarter : USCoin
    {
        public Quarter(USCoinMintMark QMint)
        {
            MintMark = QMint;
            this.Name = "Quarter";
            this.MonetaryValue = .25;

        }
        public Quarter()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Quarter";
            this.MonetaryValue = .25;
        }
    }
}
