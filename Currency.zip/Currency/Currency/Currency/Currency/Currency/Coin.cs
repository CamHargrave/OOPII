﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    public abstract class Coin : ICoin
    {
        public double MonetaryValue { get; set; }
        public string Name { get; set; }
        public int Year { get; set; }

        

        public string About()
        {
            string AboutCoins = " " + Name + " " + Year + " " + MonetaryValue;
            return AboutCoins;
        }

  

        public Coin()
        {

        }
    }
}
