﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.ViewModels;

namespace WpfApp1.Models
{
    public class CurrencyRepo : ICurrencyRepo
    {
        public List<ICoin> Coins { get; set; }

        public string About()
        {
            string About = "";
            return About;
        }

        public void AddCoin(ICoin c)
        {
            Coins.Add(c);
        }

        public ICurrencyRepo CreateChange(double Amount)
        {
            ICurrencyRepo change = new CurrencyRepo();


            while(Amount > 0.00)
            {
                if (Amount >= 1)
                {
                    Amount -= 1;
                    DollarCoin dc = new DollarCoin();
                    change.AddCoin(dc);
                }
                else if (Amount >= .50)
                {
                    Amount -= .50;
                    HalfDollar hd = new HalfDollar();
                    change.AddCoin(hd);
                }
                else if (Amount >= .25)
                {
                    Amount -= .25;
                    Quarter q = new Quarter();
                    change.AddCoin(q);
                }
                else if (Amount >= .10)
                {
                    Amount -= .10;
                   Dime d = new Dime();
                    change.AddCoin(d);
                }
                else if (Amount >= .05)
                {
                    Amount -= .05;
                    Nickel n = new Nickel();
                    change.AddCoin(n);
                }
                else if (Amount >= .01)
                {
                    Amount -= .01;
                    Penny p = new Penny();
                    change.AddCoin(p);
                }
            }
            return change;
        }
        public static ICurrencyRepo CreateChange(double AmountTendered, double TotalCost)
        {
            CurrencyRepo Money = new CurrencyRepo();
            return Money;
        }
        public CurrencyRepo()
        {

        }

        public int GetCoinCount()
        {
            return 0;
        }

        public ICurrencyRepo MakeChange(double Amount)
        {
            return CreateChange(Amount);
        }

        public ICurrencyRepo MakeChange(double AmountTendered, double TotalCost)
        {
            return CreateChange(AmountTendered, TotalCost);
        }

        public ICoin RemoveCoin(ICoin c)
        {
            Coins.Remove(c);
            return (ICoin)Coins;
        }

        public double TotalValue()
        {
            return 0;
        }

        
    }
   
}
