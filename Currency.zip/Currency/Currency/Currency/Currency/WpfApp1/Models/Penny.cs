﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    public class Penny : USCoin
    {
        public Penny(USCoinMintMark PMint)
        {
            MintMark = PMint;
            this.Name = "Penny";
            this.MonetaryValue = .01;

        }
        public Penny()
        {
            MintMark = USCoinMintMark.D;
            this.Year = System.DateTime.Now.Year;
            this.Name = "Penny";
            this.MonetaryValue = .01;
        }
    }
}
