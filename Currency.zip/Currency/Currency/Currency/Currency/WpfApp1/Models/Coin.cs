﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.ViewModels;

namespace WpfApp1.Models
{
    public abstract class Coin : ICoin
    {
        public double MonetaryValue { get; set; }
        public string Name { get; set; }
        public int Year { get; set; }

        

        public string About()
        {
            string AboutCoins = " " + Name + " " + Year + " " + MonetaryValue;
            return AboutCoins;
        }

  

        public Coin()
        {

        }
    }
}
