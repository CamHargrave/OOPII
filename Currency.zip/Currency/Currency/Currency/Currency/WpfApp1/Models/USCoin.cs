﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
        public enum USCoinMintMark
        {
            P,
            D,
            S,
            W,
        }
     public abstract class USCoin : Coin
    {
        public USCoinMintMark MintMark;
        string About()
        {
            string about = "";
            return about;
        }

        public static string GetMintNameFromMark(USCoinMintMark Mint)
        {
            return Mint.ToString();         
        }

        public USCoin()
        {

        }

    }
}
