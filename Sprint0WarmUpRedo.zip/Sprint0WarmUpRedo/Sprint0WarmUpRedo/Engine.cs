﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0WarmUpRedo
{
    public class Engine
    {
        public bool isStarted;

        public string About()
        {
            return "This is an Engine";
        }

        public Engine()
        {

        }

        public void Start()
        {

        }

        public void Stop()
        {

        }
    }
}
