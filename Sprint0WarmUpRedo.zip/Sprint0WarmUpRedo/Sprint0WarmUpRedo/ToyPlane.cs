﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0WarmUpRedo
{
    public class ToyPlane : Airplane
    {
        public bool isWoundUP;

        public string About()
        {
            return "This is a ToyPlane";
        }

        public string getWindUpString()
        {
            return "Getting windUp";
        }

        public void StartEngine()
        {

        }

        public string TakeOff()
        {
            return "Taking Off";
        }

        public ToyPlane()
        {

        }

        public void UnWind()
        {

        }

        public void WindUp()
        {

        }
    }
}
