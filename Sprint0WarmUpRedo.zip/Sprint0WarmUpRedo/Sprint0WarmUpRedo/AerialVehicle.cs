﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint0WarmUpRedo
{
    public abstract class  AerialVehicle
    {
        public int CurrentAltitude { get; set; }
        public Engine Engine { get; set; }
        public bool IsFlying { get; set; }
        public int MaxAltitude { get; set; }

        public string About()
        {
            return "This is an Aerial Vehicle";
        }

        public AerialVehicle()
        {

        }
        
        public void FlyDown()
        {

        }

        public void FlyDown(int HowManyFeet)
        {
            if(HowManyFeet > CurrentAltitude)
            {
                Console.WriteLine("If this Aerial Vehicle flys that low it will crash.");
            }
            else
            {
                CurrentAltitude -= HowManyFeet;
            }
        }

        public void FlyUp()
        {
            
        }

        public void FlyUp(int HowManyFeet)
        {
            if (HowManyFeet > MaxAltitude)
            {
                Console.WriteLine("This Aerial Vehicle cannont fly that high.");
            }
            else if (CurrentAltitude > MaxAltitude)
            {
                Console.WriteLine("This Aerial Vehicle cannot fly beyond it's max altitude.");
            }
            else
            {
                CurrentAltitude += HowManyFeet;
            }
        }

        public string getEngineStartedString()
        {
            return "Starting the engine";
        }

        public void StartEngine()
        {
            Engine.isStarted = true;
        }

        public void StopEngine()
        {
            Engine.isStarted = false;
        }

        public string TakeOff()
        {
            if (Engine.isStarted == true)
            {
                return "Engine is started, Taking Off";
            }
            else
                return "Can not take off engine is not started";

        }
    }
}
